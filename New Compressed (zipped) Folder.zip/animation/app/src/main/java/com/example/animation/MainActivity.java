package com.example.animation;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.Placeholder;

import android.graphics.drawable.Animatable;
import android.os.Bundle;
import android.transition.TransitionManager;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

public class MainActivity extends AppCompatActivity {
    ConstraintLayout layout;
    Placeholder placeholder;
    boolean flag=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        layout=findViewById(R.id.theLayout);
        placeholder=findViewById(R.id.placeholder);

    }
    public void moveimage(View v)
    {
        if(flag==false) {
            Animation zoomAnim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_in);
            v.startAnimation(zoomAnim);
            zoomAnim.setFillAfter(true);
            zoomAnim.setFillEnabled(true);
            TransitionManager.beginDelayedTransition(layout);
            placeholder.setContentId(v.getId());
            flag=true;
        }
        else if(flag==true)
        {
            Animation zoomoutAnim = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.zoom_out);
            v.startAnimation(zoomoutAnim);
            zoomoutAnim.setFillAfter(true);
            zoomoutAnim.setFillEnabled(true);
            TransitionManager.beginDelayedTransition(layout);
            placeholder.setContentId(v.getId());
            flag=false;


        }


    }
}
