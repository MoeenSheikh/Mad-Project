package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class activity6 extends AppCompatActivity {

    EditText name;
    EditText pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity6);
        name=findViewById(R.id.docint_user);
        pass=findViewById(R.id.editText15);
    }
    public void validatedoc(View v) {
        boolean flag=false;
        SharedPreferences sharedpref = getSharedPreferences("doctorinfo", Context.MODE_PRIVATE);
        int num = sharedpref.getInt("count", 0);
        String n = name.getText().toString();
        String p = pass.getText().toString();
        if(n.length()==0 || p.length()==0 )
        {
            Toast.makeText(this, "Input all fields", Toast.LENGTH_SHORT).show();
        }
        else {
            for (int i = 0; i < num; i++) {
                String rname = sharedpref.getString("username" + i, "");
                String rpass = sharedpref.getString("password" + i, "");
                if (n.equals(rname) && p.equals(rpass)) {
                    Intent intent = new Intent(this, activity9.class);
                    intent.putExtra("message",n);
                    startActivity(intent);
                    flag=true;
                }
            }

        }
        if(!flag)
        {
            Toast.makeText(this, "Wrong Input", Toast.LENGTH_SHORT).show();
        }
    }
}
