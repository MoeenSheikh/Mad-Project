package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class activity12 extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    dbsqlite mydatabase;
    Spinner spinner;
    String c;
    Button v1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity12);
        spinner=findViewById(R.id.spinner1);
        v1=findViewById(R.id.t5);
        mydatabase=new dbsqlite(this);
        ArrayAdapter<CharSequence>adapter=ArrayAdapter.createFromResource(this,R.array.area,android.R.layout.simple_spinner_item );
         adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
         spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                c = (String) parent.getItemAtPosition(position);
                Toast.makeText
                        (getApplicationContext(), "Selected : " + c, Toast.LENGTH_SHORT)
                        .show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
        searchcity();
    }
    public void home(View view)
    {
        Intent i=new Intent (this,activity10.class);
        Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show();
        startActivity(i);
    }
    public void logout(View view)
    {
        Intent i=new Intent (this,Activity5.class);
        Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
        startActivity(i);
    }
    public void searchcity(){
        v1.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        Cursor res = mydatabase.getdataofcity(c);
                        if(res.getCount()==0){
                            showMessage("Error","Nothing Found");
                            return;
                        }
                        StringBuffer buffer =new StringBuffer();
                        while(res.moveToNext()){

                            buffer.append("AREA_NAME : "+res.getString(1) + "\n");
                            buffer.append("HOSPITAL_NAME : "+res.getString(2) + "\n");
                            buffer.append("ADDRESS :  "+res.getString(3) + "\n");
                            buffer.append("PHONE_NO : "+res.getString(4) + "\n\n\n");


                        }
                        showMessage("Data",buffer.toString());
                    }
                }
        );

    }
    public void showMessage(String Title,String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);//built in function ,there can be images text etc.
        builder.setCancelable(true);
        builder.setTitle(Title);
        builder.setMessage(Message);
        builder.show();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

        if(parent.getItemAtPosition(position).equals("CHOOSE AREA"))
        {
            Toast.makeText(this, "PlEASE SELECT AREA FROM THE LIST", Toast.LENGTH_SHORT).show();
        }
        else {
            String text = parent.getItemAtPosition(position).toString();
            Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
