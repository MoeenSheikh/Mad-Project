package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class activity11 extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    dbsqlite mydatabase;
    Spinner spinner;
    String m;
    Button c1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity11);
        c1=findViewById(R.id.w5);
        mydatabase=new dbsqlite(this);
        spinner=findViewById(R.id.spinner2);
        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(this,R.array.MED,android.R.layout.simple_spinner_item );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                m = (String) parent.getItemAtPosition(position);
                Toast.makeText(getApplicationContext(), "Selected : " + m, Toast.LENGTH_SHORT).show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        searchm();


    }

    public void hme(View view)
    {
        Intent i=new Intent (this,activity10.class);
        Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show();
        startActivity(i);
    }
    public void lgout(View view)
    {
        Intent i=new Intent (this,Activity5.class);
        Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
        startActivity(i);
    }
    public void searchm(){
        c1.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        Cursor res = mydatabase.getdataofmed(m);
                        if(res.getCount()==0){
                            showMessage("Error","Nothing Found");
                            return;
                        }
                        StringBuffer buffer =new StringBuffer();
                        while(res.moveToNext()){

                            buffer.append("Name : "+res.getString(1) + "\n");
                            buffer.append("Dosage : "+res.getString(2) + "\n");
                            buffer.append("Disease:  "+res.getString(3) + "\n");
                            buffer.append("Price : "+res.getString(4) + "\n\n\n");


                        }
                        showMessage("Data",buffer.toString());
                    }
                }
        );

    }
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(parent.getItemAtPosition(position).equals("CHOOSE MEDICINE"))
        {
            Toast.makeText(this, "PlEASE SELECT MEDICINE FROM THE LIST", Toast.LENGTH_SHORT).show();
        }
        else {
            String text = parent.getItemAtPosition(position).toString();
            Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
        }
    }
    public void showMessage(String Title,String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);//built in function ,there can be images text etc.
        builder.setCancelable(true);
        builder.setTitle(Title);
        builder.setMessage(Message);
        builder.show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
