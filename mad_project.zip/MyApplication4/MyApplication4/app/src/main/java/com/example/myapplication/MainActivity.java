package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    dbsqlite myDatabase;
    private long backpr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity);
        myDatabase = new dbsqlite(this);

    }
    public void sendtotwo(View view)
    {
        Intent i=new Intent (this, Activity2.class);
        startActivity(i);
    }
    public void sendtothree(View view)
    {
        Intent i=new Intent (this, activity3.class);
        startActivity(i);
    }

    @Override
    public void onBackPressed() {

        if(backpr+2000>System.currentTimeMillis())
        {
            super.onBackPressed();
            return;
        }
        else
        {
            Toast.makeText(getBaseContext(),"Press back again to exit",Toast.LENGTH_SHORT).show();
        }
        backpr=System.currentTimeMillis();
    }
}
