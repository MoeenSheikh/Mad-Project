package com.example.myapplication;

import android.app.Application;

public class Myapplication extends Application {
    private int countG=0;

    public int getcount() {
        return countG;
    }

    public void setcount(int someVariable) {
        this.countG = someVariable;
    }
}
