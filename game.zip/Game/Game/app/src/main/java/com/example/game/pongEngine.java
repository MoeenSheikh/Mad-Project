package com.example.game;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

public class pongEngine extends SurfaceView implements Runnable{

public Thread gamethread;
public SurfaceHolder ourholder;
public volatile boolean playing;
public boolean pause;

private int screeny;
private int screenx;

private Canvas canvas;
private Paint paint;
private long fps;
private long timeThisframe;
int lives=3;
int score=0;
Bat bat;
ball Ball;
blocks []block=new blocks[200];
int numBlocks;

    public pongEngine(Context context,int x,int y) {
        super(context);
    ourholder=getHolder();
    screenx=x;
    screeny=y;
    bat=new Bat(screenx,screeny);
    paint=new Paint();
    }


    @Override
    public void run() {
        while(playing)
        {
            if(!pause)
            {
                update();
            }
            draw();
        }

    }
    public void pause()
    {
        playing=false;
        try{
            gamethread.join();
        }
        catch(InterruptedException e)
        {
            Log.e("Error","joining thread");
        }
    }
    public void resume()
    {
        playing=true;
        gamethread=new Thread(this);
        gamethread.start();
    }
    public void draw() {
        if (ourholder.getSurface().isValid()) {
            canvas = ourholder.lockCanvas();
            canvas.drawColor(Color.argb(255, 100, 50, 50));
            paint.setColor(Color.argb(255, 100, 100, 100));
            //canvas.drawRect(Ball.getRect(), paint);
            canvas.drawRect(bat.getRect(), paint);
            paint.setColor(Color.argb(255, 25, 25, 200));
            paint.setTextSize(40);
            canvas.drawText("Score: "+score+" lives: "+lives,screenx,screeny,paint);
            ourholder.unlockCanvasAndPost(canvas);
        }
    }
    public boolean onTouchEvent(MotionEvent motionevent)
    {
        switch (motionevent.getAction()&MotionEvent.ACTION_MASK){
            case MotionEvent.ACTION_DOWN:
                pause=false;
                if(motionevent.getX()>screenx/2)
                {
                    bat.setmovement(bat.right);
                }
                else
                {
                    bat.setmovement(bat.left);
                }
        }
        return true;
    }
    public void update()
    {
        bat.update(60);
    }


}
