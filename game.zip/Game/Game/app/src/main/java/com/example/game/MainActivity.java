package com.example.game;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;

public class MainActivity extends Activity {




    pongEngine Pongengine;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Display display=getWindowManager().getDefaultDisplay();
        Point size=new Point();
        display.getSize(size);
        Pongengine=new pongEngine(this,size.x,size.y);
        setContentView(Pongengine);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Pongengine.pause();
    }
    @Override
    protected void onResume() {
        super.onResume();
        Pongengine.resume();
    }

}
