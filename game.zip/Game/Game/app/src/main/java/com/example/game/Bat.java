package com.example.game;

import android.graphics.RectF;

public class Bat {
    private RectF rect;
    private float length;
    private float x;
    private float batspeed;
    final int stopped=0;
    final int left=1;
    final int right=2;
    private  int batmoving=stopped;
    Bat(int scx,int scy)
    {
        length=130;
        float height=40;
        x=scx/2;
        float y=scy-40;
        rect=new RectF(x,y,x+length,y+height);
        batspeed=350;
    }
    RectF getRect()
    {
        return rect;
    }
    void setmovement(int state)
    {
        batmoving=state;
    }
    void update(long fps)
    {
        if(batmoving==left)
        {
            x=x-batspeed/fps;
        }
        if(batmoving==right)
        {
            x=x+batspeed/fps;
        }
        rect.left=x;
        rect.right=x+length;
    }

}
