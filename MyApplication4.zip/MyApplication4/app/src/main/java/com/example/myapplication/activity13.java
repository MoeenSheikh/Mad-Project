package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class activity13 extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    Spinner spinner;
    dbsqlite myDatabase;
    String a;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity13);

        myDatabase=new dbsqlite(this);
        spinner=findViewById(R.id.spinner3);
        b1=findViewById(R.id.m5);
        ArrayAdapter<CharSequence> adapter=ArrayAdapter.createFromResource(this,R.array.DIS,android.R.layout.simple_spinner_item );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
       spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                 a = (String) parent.getItemAtPosition(position);
                Toast.makeText
                        (getApplicationContext(), "Selected : " + a, Toast.LENGTH_SHORT)
                        .show();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
       search1();
        }
    public void hom(View view)
    {
        Intent i=new Intent (this,activity10.class);
        Toast.makeText(this, "Home", Toast.LENGTH_SHORT).show();
        startActivity(i);
    }

    public void search1(){
        b1.setOnClickListener(
          new View.OnClickListener(){
              @Override
              public void onClick(View v) {
                  Cursor res = myDatabase.getdata(a);
                if(res.getCount()==0){
                    showMessage("Error","Nothing Found");
                    return;
                }
                StringBuffer buffer =new StringBuffer();
               while(res.moveToNext()){

                    buffer.append("Name : "+res.getString(1) + "\n");
                    buffer.append("Doasage : "+res.getString(2) + "\n");
                    buffer.append("Disease:  "+res.getString(3) + "\n");
                    buffer.append("Price : "+res.getString(4) + "\n\n\n");


                }
                  showMessage("Data",buffer.toString());
              }
          }
        );

    }
    public void logou(View view)
    {
        Intent i=new Intent (this,Activity5.class);
        Toast.makeText(this, "Logout", Toast.LENGTH_SHORT).show();
        startActivity(i);
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        if(parent.getItemAtPosition(position).equals("CHOOSE DISEASE"))
        {
            Toast.makeText(this, "PlEASE SELECT DISEASE FROM THE LIST", Toast.LENGTH_SHORT).show();
        }
        else {
            String text = parent.getItemAtPosition(position).toString();
            Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
        }
    }

    public void showMessage(String Title,String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);//built in function ,there can be images text etc.
        builder.setCancelable(true);
        builder.setTitle(Title);
        builder.setMessage(Message);
        builder.show();
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
