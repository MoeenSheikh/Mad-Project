package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import static java.lang.Integer.parseInt;

public class Activity7 extends AppCompatActivity {

    EditText usernameinput;
    EditText passwordinput;
    EditText numberinput;
    EditText email;
    EditText hospital;
    EditText address;
    EditText timing;
    EditText gender;
    int c=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_7);
        usernameinput=findViewById(R.id.editText6);
        passwordinput=findViewById(R.id.editText13);
        numberinput=findViewById(R.id.editText7);
        email=findViewById(R.id.editText8);
        hospital=findViewById(R.id.editText9);
        address=findViewById(R.id.editText10);
        timing=findViewById(R.id.editText11);
        gender=findViewById(R.id.editText12);
    }
    public void savedocinfo(View view) {
        SharedPreferences sharedpref = getSharedPreferences("doctorinfo", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedpref.edit();
        int num=sharedpref.getInt("count",0);
        c=num;
        String u,p,e,a,g,h,t;
        int m;
        u=usernameinput.getText().toString();
        p=passwordinput.getText().toString();
        e=email.getText().toString();
        a=address.getText().toString();
        g=gender.getText().toString();
        h= hospital.getText().toString();
        t=timing.getText().toString();
        m=Integer.parseInt(numberinput.getText().toString());
        if(u.length()==0 || p.length()==0 || e.length()==0||a.length()==0||g.length()==0 || h.length()==0||t.length()==0)
        {
            Toast.makeText(this, "Input all fields", Toast.LENGTH_SHORT).show();
        }
        else {
            editor.putString("username" + c, u);
            editor.putString("password" + c, p);
            editor.putInt("myint" + c, m);
            editor.putString("Email" + c, e);
            editor.putString("Hospital" + c, h);
            editor.putString("Address" + c, a);
            editor.putString("Timing" + c, t);
            editor.putString("Gender" + c, g);
            c++;
            editor.putInt("count", parseInt(String.valueOf(c)));
            editor.apply();
            Toast.makeText(this, "Data Saved", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(this, activity6.class);
            startActivity(i);
        }
    }

}
