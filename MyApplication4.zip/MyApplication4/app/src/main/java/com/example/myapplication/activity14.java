package com.example.myapplication;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class activity14 extends AppCompatActivity {
    dbsqlite myDatabase;
    EditText editdes,editmed,editdos,editpr;
    Button btnAddData, btnViewAll, btnUpdate, btnDelete;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity14);
        myDatabase = new  dbsqlite(this);
        editdes = (EditText) findViewById(R.id.pd10);
        editmed = (EditText) findViewById(R.id.pd3);
        editdos=(EditText)findViewById(R.id.pd4);
        editpr = (EditText) findViewById(R.id.pd5);

        btnAddData = (Button) findViewById(R.id.pd6);
        btnViewAll = (Button) findViewById(R.id.pd7);
        btnUpdate = (Button) findViewById(R.id.pd9);
        btnDelete = (Button) findViewById(R.id.pd8);
        AddData();
        UpdateData();
        ViewAll();
        deleteData();
    }
    public void AddData(){
        btnAddData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean isInserted = myDatabase.insertData(
                        editmed.getText().toString(),
                        editdos.getText().toString()
                        ,editdes.getText().toString(),
                        editpr.getText().toString());

                if(isInserted==true) {
                    Toast.makeText(activity14.this, "Data Inserted", Toast.LENGTH_LONG).show();
                } else{
                    Toast.makeText(activity14.this,"Data Not Inserted",Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    public void UpdateData() {
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
                    public void onClick(View v) {
                       boolean isInserted = myDatabase.updateData(
                        editmed.getText().toString(),
                        editdos.getText().toString()
                        ,editdes.getText().toString(),
                        editpr.getText().toString());

                     if(isInserted==true) {
                        Toast.makeText(activity14.this, "Data Updated", Toast.LENGTH_LONG).show();
                    } else{
                        Toast.makeText(activity14.this,"Data Not Updated",Toast.LENGTH_LONG).show();
                    }
                }
              });
             }
    public void ViewAll(){
        btnViewAll.setOnClickListener(
                new View.OnClickListener(){
                    @Override
                    public void onClick(View v) {
                        Cursor res = myDatabase.getAllDataR();

                        if(res.getCount()==0 ){
                            showMessage("Error","Nothing Found");
                            return;
                        }
                        StringBuffer buffer =new StringBuffer();
                        while(res.moveToNext()){

                            buffer.append("Name : "+res.getString(1) + "\n");
                            buffer.append("Doasage : "+res.getString(2) + "\n");
                            buffer.append("Disease:  "+res.getString(3) + "\n");
                            buffer.append("Price : "+res.getString(4) + "\n\n\n");

                        }
                        showMessage("Data",buffer.toString());
                    }
                }
        );
    }

    public void showMessage(String Title,String Message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);//built in function ,there can be images text etc.
        builder.setCancelable(true);
        builder.setTitle(Title);
        builder.setMessage(Message);
        builder.show();
    }
    public void deleteData(){
        btnDelete.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Integer deletedRows=myDatabase.deleteData(editdes.getText().toString());
                if(deletedRows>0)
                {
                    Toast.makeText(activity14.this, "Data Deleted", Toast.LENGTH_LONG).show();
                }
                else{
                    Toast.makeText(activity14.this,"Data Not Deleted",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
