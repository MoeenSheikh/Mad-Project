package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import static java.lang.Integer.parseInt;

public class activity8 extends AppCompatActivity {

    EditText usernameinput;
    EditText passwordinput;
    EditText numberinput;
    EditText email;
    EditText address;
    EditText gender;
    int c1=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity8);
        usernameinput=findViewById(R.id.editText);
        passwordinput=findViewById(R.id.editText14);
        numberinput=findViewById(R.id.editText2);
        email=findViewById(R.id.editText3);
        address=findViewById(R.id.editText4);
        gender=findViewById(R.id.editText5);
    }
    public void saveinfo(View view) {
        SharedPreferences shared = getSharedPreferences("patientinfo", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor1 = shared.edit();
        int num1=shared.getInt("count",0);
        c1=num1;
        String u,p,e,a,g;
        int m;
        u=usernameinput.getText().toString();
        p=passwordinput.getText().toString();
        e=email.getText().toString();
        a=address.getText().toString();
        g=gender.getText().toString();
        m=Integer.parseInt(numberinput.getText().toString());
        if(u.length()==0 || p.length()==0 || e.length()==0||a.length()==0||g.length()==0)
        {
            Toast.makeText(this, "Input all fields", Toast.LENGTH_SHORT).show();
        }
        else {
            editor1.putString("username" + c1, u);
            editor1.putString("password" + c1, p);
            editor1.putInt("myint" + c1, m);
            editor1.putString("Email" + c1, e);
            editor1.putString("Address" + c1, a);
            editor1.putString("Gender" + c1, g);
            c1++;
            editor1.putInt("count", parseInt(String.valueOf(c1)));
            editor1.apply();
            Toast.makeText(this, "Data Saved", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(this, Activity5.class);
            startActivity(i);
        }
    }

}
